/*
 * LCD.h
 *
 * Created: 2/1/2023 7:51:52 PM
 *  Author: Merlin
 */ 

#define  F_CPU 8000000UL

#ifndef LCD_H_
#define LCD_H_

#include "StdTypes.h"
#include "DIO_interface.h"
#include <util/delay.h>
/***************************config***********************/

#define  LCD_PORT      PD
#define  RS            PINC0
#define  RW            PINC1
#define  EN            PINC2
/********************************************************/

void LCD_WriteCommand(u8 command);
void LCD_WriteData(u8 data);
void LCD_Init(void);

#endif /* LCD_H_ */